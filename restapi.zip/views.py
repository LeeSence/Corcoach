from django.shortcuts import render
#from .serializers import Coach_picSerializer
#from enfpapp.models import coach_pic
from rest_framework import viewsets

# Create your views here.
#class Coach_picViewSet(viewsets.ModelViewSet):
#    # 데이터베이스 모든 정보를 전달
#    queryset = coach_pic.objects.all()
#    # 데이터베이스의 serializer된 클래스 정보를 view에 전달
#    serializer_class = Coach_picSerializer

